## 1. Expressions

An **expression** is any piece of code that evaluates to (produces) a value. Expressions are the 'questions' or 'calculations' that JavaScript answers with a value.

**Key Concepts**: if you can assign a piece of code to a variable or pass it to a function, then that code is an **expression**.

## 2. Statements

A **statement** is an instruction or action for the computer to perform. Statements do things, but don't necessarily produce values. They're the 'commands' in your code.

**Key Concepts**: Statements make things happen. Expressions answer questions.

All Expressions are Statements but not all Statements are Expressions.

## 3. Operators
Operators are special symbols that perform opertions on values (aka operands). They are the 'verbs' that act on your data.

**Operands** are the values the operators work on: For example: In `5 + 3`, the `+` is the operator, and `5` and `3` are the operands.



## 4. Type Conversion

## 5. Control Flow

## 6. Functions