// 1. Arithmetic Operators
// Perform mathematical operations on numbers.

let a = 10
let b = 3

// Basic Arithmetic
a + b  // 13 - addition
a - b // 10  - subtraction
a * b // 30  - multiplication
a / b // 3.3333... - division
a % b // 1 - modulus (remainder)
a ** b // 1000 - power/exponentiation


// more modulus operator examples
10 % 2 // 0
17 % 5 // 2
21 % 5 // 1

// 2. Assignment Operator
// Assign values to variables, often with a calculation.

let x = 5  // basic assignment
x = x + 2 // x is now 7

// Compound assignment (shorthand assignment)
x += 3 // x = x + 3 // which is equal to 10
