// Expressions

// 1. Literal Expressions
90            // 90
'Hello World' // Hello World
true          // true

// 2. Arithmetic Expressions
5 + 3     // 8
10 * 2    // 20
16 / 4    // 4


// 3. String Expressions
'Jasseh' + ' ' + 'Code' + ' ' + 'Camp' // Jasseh Code Camp
`My age is ${30}`                      // My age is 30

// 4. Variable Expression
let age = 20  // this is actually a statement
let firstName = 'Ansumana' // and this too is a statement

age    // Now we are evaluating age, which is an expression
age + 1 // this is also an expression. Adding one to age.

// 5. Logical Expressions
5 > 3    // true
age >= 18 // false
true && false // false


// 6. Function call expressions
Math.pow(2, 10) // 1024
Math.max(5, 10) // 10
'Hello'.toLowerCase() // hello
(new Date()).getFullYear() // 2025
console.log(age) // Outputs the value of age.

// Statements

// 1. Declaration Statements
let studentAge = 25       // initializes a variable
const name = 'Ansumana'   // initializes a constant variable
let score = 0;                // declares a variable


// 2. Assignment statements
age = 26           // assigns new value
score += 10        // assigns modified value

// 3. Conditional statements
if (age >= 18) {    // executes code conditionally
    console.log('You are an adult');
}

// 4. Loop statements
for (let i = 0; i < 5; i++) {  // repeats code
    console.log(i)
}

// 5. Function declaration statements
function greet() {             // defines a function
    console.log('Hello')
}

// 6. Return statements
function add(num1, num2) {
    return num1 + num2
}